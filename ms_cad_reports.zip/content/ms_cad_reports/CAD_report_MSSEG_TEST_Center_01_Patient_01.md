# MS-CAD Report - Case MSSEG_TEST_Center_01_Patient_01
_Generated: 2026-09-12 21:26_

> Research quantification output, not a validated diagnostic device. Categories are based on standardized 50/500 mm3 volume thresholds.

## Summary (Predicted)
- **Count:** 12 | **Vol:** 0.637 mL
  - small (<50mm3): 6
  - medium (50-500mm3): 6
  - large (>500mm3): 0

## Validation vs Ground Truth
- **GT Count:** 6 | **GT Vol:** 0.356 mL
- **Detection TP/FP/FN:** 3/9/3
- **Precision/Recall/F1:** 0.250/0.500/0.333

## Lesion Detail (Predicted)
| # | Vol (mm3) | Category | Centroid |
|---|---|---|---|
| 1 | 168.0 | medium (50-500mm3) | (41.8, 47.8, 79.1) |
| 2 | 114.0 | medium (50-500mm3) | (84.9, 106.9, 90.1) |
| 3 | 92.0 | medium (50-500mm3) | (94.4, 60.6, 81.2) |
| 4 | 82.0 | medium (50-500mm3) | (70.3, 114.0, 76.8) |
| 5 | 78.0 | medium (50-500mm3) | (52.6, 70.1, 87.7) |
| 6 | 63.0 | medium (50-500mm3) | (102.0, 57.4, 64.1) |
| 7 | 12.0 | small (<50mm3) | (93.7, 32.7, 70.6) |
| 8 | 7.0 | small (<50mm3) | (55.1, 121.6, 73.6) |
| 9 | 7.0 | small (<50mm3) | (76.4, 65.9, 95.6) |
| 10 | 5.0 | small (<50mm3) | (64.4, 125.8, 48.6) |
| 11 | 5.0 | small (<50mm3) | (69.2, 44.2, 0.6) |
| 12 | 4.0 | small (<50mm3) | (86.5, 54.5, 73.0) |