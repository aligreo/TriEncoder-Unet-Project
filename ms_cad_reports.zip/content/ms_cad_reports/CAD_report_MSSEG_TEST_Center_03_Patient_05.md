# MS-CAD Report - Case MSSEG_TEST_Center_03_Patient_05
_Generated: 2026-09-12 21:27_

> Research quantification output, not a validated diagnostic device. Categories are based on standardized 50/500 mm3 volume thresholds.

## Summary (Predicted)
- **Count:** 24 | **Vol:** 3.501 mL
  - small (<50mm3): 10
  - medium (50-500mm3): 12
  - large (>500mm3): 2

## Validation vs Ground Truth
- **GT Count:** 19 | **GT Vol:** 5.019 mL
- **Detection TP/FP/FN:** 14/7/5
- **Precision/Recall/F1:** 0.667/0.737/0.700

## Lesion Detail (Predicted)
| # | Vol (mm3) | Category | Centroid |
|---|---|---|---|
| 1 | 941.0 | large (>500mm3) | (33.5, 46.2, 56.3) |
| 2 | 800.0 | large (>500mm3) | (94.4, 41.6, 69.1) |
| 3 | 436.0 | medium (50-500mm3) | (58.9, 124.0, 71.0) |
| 4 | 215.0 | medium (50-500mm3) | (47.8, 58.1, 87.3) |
| 5 | 187.0 | medium (50-500mm3) | (99.9, 59.2, 56.7) |
| 6 | 170.0 | medium (50-500mm3) | (84.0, 22.8, 62.5) |
| 7 | 98.0 | medium (50-500mm3) | (49.4, 107.3, 97.7) |
| 8 | 83.0 | medium (50-500mm3) | (49.4, 112.6, 90.4) |
| 9 | 70.0 | medium (50-500mm3) | (87.6, 25.7, 27.2) |
| 10 | 69.0 | medium (50-500mm3) | (33.3, 76.4, 49.4) |
| 11 | 66.0 | medium (50-500mm3) | (91.0, 98.2, 94.5) |
| 12 | 66.0 | medium (50-500mm3) | (95.1, 82.2, 50.6) |
| 13 | 54.0 | medium (50-500mm3) | (41.5, 35.4, 64.4) |
| 14 | 51.0 | medium (50-500mm3) | (90.5, 96.0, 39.0) |
| 15 | 48.0 | small (<50mm3) | (29.5, 62.5, 110.5) |
| 16 | 43.0 | small (<50mm3) | (85.1, 120.5, 64.5) |
| 17 | 22.0 | small (<50mm3) | (86.3, 78.0, 113.1) |
| 18 | 17.0 | small (<50mm3) | (47.2, 92.7, 95.4) |
| 19 | 17.0 | small (<50mm3) | (50.9, 17.2, 68.8) |
| 20 | 16.0 | small (<50mm3) | (51.1, 91.1, 96.7) |
| 21 | 15.0 | small (<50mm3) | (47.3, 47.2, 93.7) |
| 22 | 7.0 | small (<50mm3) | (59.4, 89.9, 115.7) |
| 23 | 5.0 | small (<50mm3) | (38.6, 43.8, 65.0) |
| 24 | 5.0 | small (<50mm3) | (82.6, 99.0, 85.6) |