# MS-CAD Report - Case MSSEG_TEST_Center_08_Patient_05
_Generated: 2026-09-12 21:27_

> Research quantification output, not a validated diagnostic device. Categories are based on standardized 50/500 mm3 volume thresholds.

## Summary (Predicted)
- **Count:** 21 | **Vol:** 1.526 mL
  - small (<50mm3): 10
  - medium (50-500mm3): 11
  - large (>500mm3): 0

## Validation vs Ground Truth
- **GT Count:** 4 | **GT Vol:** 0.121 mL
- **Detection TP/FP/FN:** 4/17/0
- **Precision/Recall/F1:** 0.191/1.000/0.320

## Lesion Detail (Predicted)
| # | Vol (mm3) | Category | Centroid |
|---|---|---|---|
| 1 | 227.0 | medium (50-500mm3) | (78.9, 119.6, 72.2) |
| 2 | 206.0 | medium (50-500mm3) | (52.6, 76.9, 91.7) |
| 3 | 181.0 | medium (50-500mm3) | (82.6, 84.1, 91.5) |
| 4 | 159.0 | medium (50-500mm3) | (90.5, 29.3, 62.0) |
| 5 | 124.0 | medium (50-500mm3) | (49.8, 117.3, 73.0) |
| 6 | 97.0 | medium (50-500mm3) | (56.7, 16.8, 64.6) |
| 7 | 84.0 | medium (50-500mm3) | (96.2, 47.6, 80.1) |
| 8 | 66.0 | medium (50-500mm3) | (89.7, 118.1, 66.9) |
| 9 | 65.0 | medium (50-500mm3) | (95.3, 100.6, 91.7) |
| 10 | 59.0 | medium (50-500mm3) | (37.0, 123.2, 78.6) |
| 11 | 54.0 | medium (50-500mm3) | (97.0, 67.0, 61.6) |
| 12 | 45.0 | small (<50mm3) | (51.8, 106.6, 91.5) |
| 13 | 39.0 | small (<50mm3) | (88.5, 52.2, 113.1) |
| 14 | 36.0 | small (<50mm3) | (55.9, 60.9, 76.0) |
| 15 | 35.0 | small (<50mm3) | (105.4, 92.5, 91.9) |
| 16 | 15.0 | small (<50mm3) | (90.9, 67.3, 78.3) |
| 17 | 11.0 | small (<50mm3) | (50.5, 116.8, 82.9) |
| 18 | 9.0 | small (<50mm3) | (94.7, 51.0, 77.6) |
| 19 | 6.0 | small (<50mm3) | (41.3, 51.8, 64.5) |
| 20 | 5.0 | small (<50mm3) | (50.4, 62.2, 84.2) |
| 21 | 3.0 | small (<50mm3) | (46.3, 50.3, 82.0) |