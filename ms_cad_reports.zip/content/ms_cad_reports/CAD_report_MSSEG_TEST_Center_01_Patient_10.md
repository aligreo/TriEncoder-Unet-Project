# MS-CAD Report - Case MSSEG_TEST_Center_01_Patient_10
_Generated: 2026-09-12 21:27_

> Research quantification output, not a validated diagnostic device. Categories are based on standardized 50/500 mm3 volume thresholds.

## Summary (Predicted)
- **Count:** 23 | **Vol:** 3.711 mL
  - small (<50mm3): 9
  - medium (50-500mm3): 12
  - large (>500mm3): 2

## Validation vs Ground Truth
- **GT Count:** 30 | **GT Vol:** 5.165 mL
- **Detection TP/FP/FN:** 17/3/13
- **Precision/Recall/F1:** 0.850/0.567/0.680

## Lesion Detail (Predicted)
| # | Vol (mm3) | Category | Centroid |
|---|---|---|---|
| 1 | 796.0 | large (>500mm3) | (42.4, 62.4, 88.2) |
| 2 | 595.0 | large (>500mm3) | (53.4, 117.5, 91.9) |
| 3 | 358.0 | medium (50-500mm3) | (85.7, 113.8, 92.6) |
| 4 | 307.0 | medium (50-500mm3) | (85.5, 47.7, 21.5) |
| 5 | 276.0 | medium (50-500mm3) | (42.3, 86.1, 96.8) |
| 6 | 273.0 | medium (50-500mm3) | (51.4, 74.4, 96.9) |
| 7 | 245.0 | medium (50-500mm3) | (40.6, 39.6, 69.3) |
| 8 | 192.0 | medium (50-500mm3) | (86.3, 84.0, 97.6) |
| 9 | 128.0 | medium (50-500mm3) | (39.6, 94.0, 89.9) |
| 10 | 85.0 | medium (50-500mm3) | (91.9, 70.3, 99.9) |
| 11 | 82.0 | medium (50-500mm3) | (103.7, 47.2, 64.2) |
| 12 | 63.0 | medium (50-500mm3) | (69.1, 66.3, 81.9) |
| 13 | 58.0 | medium (50-500mm3) | (90.3, 39.6, 96.4) |
| 14 | 50.0 | medium (50-500mm3) | (99.2, 76.5, 92.2) |
| 15 | 38.0 | small (<50mm3) | (94.9, 101.4, 94.1) |
| 16 | 35.0 | small (<50mm3) | (85.3, 130.4, 99.6) |
| 17 | 34.0 | small (<50mm3) | (91.2, 115.8, 82.1) |
| 18 | 28.0 | small (<50mm3) | (52.5, 98.6, 98.6) |
| 19 | 22.0 | small (<50mm3) | (51.1, 133.0, 96.0) |
| 20 | 20.0 | small (<50mm3) | (90.0, 26.6, 60.1) |
| 21 | 17.0 | small (<50mm3) | (50.2, 26.9, 59.1) |
| 22 | 6.0 | small (<50mm3) | (81.7, 74.7, 124.5) |
| 23 | 3.0 | small (<50mm3) | (92.3, 52.7, 106.0) |