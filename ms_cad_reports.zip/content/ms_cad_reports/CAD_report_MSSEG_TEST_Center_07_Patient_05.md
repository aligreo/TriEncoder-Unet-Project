# MS-CAD Report - Case MSSEG_TEST_Center_07_Patient_05
_Generated: 2026-09-12 21:27_

> Research quantification output, not a validated diagnostic device. Categories are based on standardized 50/500 mm3 volume thresholds.

## Summary (Predicted)
- **Count:** 13 | **Vol:** 1.272 mL
  - small (<50mm3): 7
  - medium (50-500mm3): 6
  - large (>500mm3): 0

## Validation vs Ground Truth
- **GT Count:** 12 | **GT Vol:** 1.485 mL
- **Detection TP/FP/FN:** 11/1/1
- **Precision/Recall/F1:** 0.917/0.917/0.917

## Lesion Detail (Predicted)
| # | Vol (mm3) | Category | Centroid |
|---|---|---|---|
| 1 | 380.0 | medium (50-500mm3) | (48.9, 112.2, 71.2) |
| 2 | 226.0 | medium (50-500mm3) | (45.7, 66.1, 80.4) |
| 3 | 201.0 | medium (50-500mm3) | (91.2, 46.1, 83.9) |
| 4 | 121.0 | medium (50-500mm3) | (34.8, 49.3, 66.5) |
| 5 | 95.0 | medium (50-500mm3) | (95.9, 51.9, 68.0) |
| 6 | 59.0 | medium (50-500mm3) | (82.8, 102.1, 92.4) |
| 7 | 48.0 | small (<50mm3) | (49.2, 81.9, 85.3) |
| 8 | 38.0 | small (<50mm3) | (40.4, 115.1, 78.8) |
| 9 | 34.0 | small (<50mm3) | (91.7, 58.4, 85.0) |
| 10 | 29.0 | small (<50mm3) | (88.2, 121.7, 77.9) |
| 11 | 26.0 | small (<50mm3) | (75.0, 102.2, 80.5) |
| 12 | 11.0 | small (<50mm3) | (90.5, 50.1, 78.5) |
| 13 | 4.0 | small (<50mm3) | (82.0, 57.5, 80.0) |