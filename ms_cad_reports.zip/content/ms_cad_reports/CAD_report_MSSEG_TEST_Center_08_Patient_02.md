# MS-CAD Report - Case MSSEG_TEST_Center_08_Patient_02
_Generated: 2026-09-12 21:27_

> Research quantification output, not a validated diagnostic device. Categories are based on standardized 50/500 mm3 volume thresholds.

## Summary (Predicted)
- **Count:** 13 | **Vol:** 2.335 mL
  - small (<50mm3): 6
  - medium (50-500mm3): 5
  - large (>500mm3): 2

## Validation vs Ground Truth
- **GT Count:** 8 | **GT Vol:** 1.492 mL
- **Detection TP/FP/FN:** 7/6/1
- **Precision/Recall/F1:** 0.538/0.875/0.667

## Lesion Detail (Predicted)
| # | Vol (mm3) | Category | Centroid |
|---|---|---|---|
| 1 | 680.0 | large (>500mm3) | (51.5, 118.1, 94.5) |
| 2 | 535.0 | large (>500mm3) | (83.1, 117.6, 94.6) |
| 3 | 415.0 | medium (50-500mm3) | (51.3, 28.9, 64.0) |
| 4 | 244.0 | medium (50-500mm3) | (93.2, 31.1, 63.6) |
| 5 | 140.0 | medium (50-500mm3) | (84.1, 85.3, 100.7) |
| 6 | 121.0 | medium (50-500mm3) | (52.4, 80.9, 100.3) |
| 7 | 120.0 | medium (50-500mm3) | (40.5, 46.7, 69.1) |
| 8 | 36.0 | small (<50mm3) | (31.5, 41.3, 69.8) |
| 9 | 24.0 | small (<50mm3) | (38.5, 128.5, 85.5) |
| 10 | 8.0 | small (<50mm3) | (87.4, 30.6, 62.8) |
| 11 | 6.0 | small (<50mm3) | (45.5, 53.0, 82.0) |
| 12 | 3.0 | small (<50mm3) | (83.7, 90.0, 116.7) |
| 13 | 3.0 | small (<50mm3) | (87.0, 115.7, 99.7) |