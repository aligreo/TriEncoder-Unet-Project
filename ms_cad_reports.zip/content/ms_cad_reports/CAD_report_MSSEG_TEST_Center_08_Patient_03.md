# MS-CAD Report - Case MSSEG_TEST_Center_08_Patient_03
_Generated: 2026-09-12 21:27_

> Research quantification output, not a validated diagnostic device. Categories are based on standardized 50/500 mm3 volume thresholds.

## Summary (Predicted)
- **Count:** 14 | **Vol:** 1.673 mL
  - small (<50mm3): 6
  - medium (50-500mm3): 8
  - large (>500mm3): 0

## Validation vs Ground Truth
- **GT Count:** 14 | **GT Vol:** 0.795 mL
- **Detection TP/FP/FN:** 8/7/6
- **Precision/Recall/F1:** 0.533/0.571/0.552

## Lesion Detail (Predicted)
| # | Vol (mm3) | Category | Centroid |
|---|---|---|---|
| 1 | 380.0 | medium (50-500mm3) | (91.4, 53.3, 85.2) |
| 2 | 285.0 | medium (50-500mm3) | (86.4, 101.2, 131.9) |
| 3 | 232.0 | medium (50-500mm3) | (55.1, 52.4, 79.7) |
| 4 | 168.0 | medium (50-500mm3) | (52.7, 24.2, 48.1) |
| 5 | 147.0 | medium (50-500mm3) | (89.5, 27.7, 63.1) |
| 6 | 109.0 | medium (50-500mm3) | (92.1, 109.1, 59.6) |
| 7 | 77.0 | medium (50-500mm3) | (62.9, 68.9, 93.3) |
| 8 | 72.0 | medium (50-500mm3) | (46.6, 69.3, 102.2) |
| 9 | 43.0 | small (<50mm3) | (104.8, 59.2, 81.7) |
| 10 | 42.0 | small (<50mm3) | (45.1, 107.9, 117.1) |
| 11 | 38.0 | small (<50mm3) | (64.6, 57.0, 40.4) |
| 12 | 34.0 | small (<50mm3) | (106.8, 66.9, 107.2) |
| 13 | 31.0 | small (<50mm3) | (38.5, 103.5, 65.8) |
| 14 | 15.0 | small (<50mm3) | (98.6, 43.6, 82.1) |