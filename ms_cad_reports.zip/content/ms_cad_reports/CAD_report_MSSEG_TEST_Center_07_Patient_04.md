# MS-CAD Report - Case MSSEG_TEST_Center_07_Patient_04
_Generated: 2026-09-12 21:27_

> Research quantification output, not a validated diagnostic device. Categories are based on standardized 50/500 mm3 volume thresholds.

## Summary (Predicted)
- **Count:** 27 | **Vol:** 17.402 mL
  - small (<50mm3): 9
  - medium (50-500mm3): 14
  - large (>500mm3): 4

## Validation vs Ground Truth
- **GT Count:** 27 | **GT Vol:** 11.379 mL
- **Detection TP/FP/FN:** 24/8/3
- **Precision/Recall/F1:** 0.750/0.889/0.814

## Lesion Detail (Predicted)
| # | Vol (mm3) | Category | Centroid |
|---|---|---|---|
| 1 | 8216.0 | large (>500mm3) | (39.3, 58.5, 71.4) |
| 2 | 4472.0 | large (>500mm3) | (91.3, 46.5, 74.3) |
| 3 | 1397.0 | large (>500mm3) | (88.7, 120.8, 92.5) |
| 4 | 1341.0 | large (>500mm3) | (53.1, 121.7, 94.6) |
| 5 | 424.0 | medium (50-500mm3) | (109.5, 77.1, 59.0) |
| 6 | 244.0 | medium (50-500mm3) | (89.4, 72.2, 90.2) |
| 7 | 235.0 | medium (50-500mm3) | (101.6, 113.0, 53.2) |
| 8 | 199.0 | medium (50-500mm3) | (85.7, 63.8, 111.2) |
| 9 | 103.0 | medium (50-500mm3) | (47.5, 130.5, 104.1) |
| 10 | 87.0 | medium (50-500mm3) | (83.6, 91.5, 112.6) |
| 11 | 84.0 | medium (50-500mm3) | (101.0, 59.7, 79.5) |
| 12 | 74.0 | medium (50-500mm3) | (98.7, 81.7, 91.6) |
| 13 | 70.0 | medium (50-500mm3) | (48.2, 70.7, 102.3) |
| 14 | 62.0 | medium (50-500mm3) | (82.9, 93.9, 104.0) |
| 15 | 59.0 | medium (50-500mm3) | (60.9, 131.2, 109.7) |
| 16 | 54.0 | medium (50-500mm3) | (59.9, 96.6, 122.6) |
| 17 | 52.0 | medium (50-500mm3) | (97.3, 131.7, 93.5) |
| 18 | 51.0 | medium (50-500mm3) | (81.4, 56.8, 67.7) |
| 19 | 49.0 | small (<50mm3) | (71.7, 70.3, 75.1) |
| 20 | 31.0 | small (<50mm3) | (95.1, 128.0, 84.4) |
| 21 | 29.0 | small (<50mm3) | (101.8, 32.3, 70.5) |
| 22 | 15.0 | small (<50mm3) | (56.3, 83.9, 115.1) |
| 23 | 12.0 | small (<50mm3) | (25.8, 86.1, 66.4) |
| 24 | 12.0 | small (<50mm3) | (111.2, 77.1, 53.7) |
| 25 | 10.0 | small (<50mm3) | (34.4, 98.6, 109.3) |
| 26 | 10.0 | small (<50mm3) | (100.4, 57.6, 54.0) |
| 27 | 10.0 | small (<50mm3) | (104.8, 69.1, 91.8) |