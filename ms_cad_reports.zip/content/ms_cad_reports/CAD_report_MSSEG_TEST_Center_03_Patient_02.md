# MS-CAD Report - Case MSSEG_TEST_Center_03_Patient_02
_Generated: 2026-09-12 21:27_

> Research quantification output, not a validated diagnostic device. Categories are based on standardized 50/500 mm3 volume thresholds.

## Summary (Predicted)
- **Count:** 30 | **Vol:** 3.390 mL
  - small (<50mm3): 16
  - medium (50-500mm3): 13
  - large (>500mm3): 1

## Validation vs Ground Truth
- **GT Count:** 19 | **GT Vol:** 4.234 mL
- **Detection TP/FP/FN:** 18/7/1
- **Precision/Recall/F1:** 0.720/0.947/0.818

## Lesion Detail (Predicted)
| # | Vol (mm3) | Category | Centroid |
|---|---|---|---|
| 1 | 674.0 | large (>500mm3) | (32.2, 61.4, 58.6) |
| 2 | 369.0 | medium (50-500mm3) | (53.2, 90.2, 92.1) |
| 3 | 315.0 | medium (50-500mm3) | (36.8, 62.3, 83.8) |
| 4 | 266.0 | medium (50-500mm3) | (40.8, 92.0, 89.9) |
| 5 | 263.0 | medium (50-500mm3) | (83.7, 56.2, 96.7) |
| 6 | 244.0 | medium (50-500mm3) | (42.4, 46.7, 76.7) |
| 7 | 187.0 | medium (50-500mm3) | (47.3, 27.0, 63.1) |
| 8 | 132.0 | medium (50-500mm3) | (81.7, 116.3, 83.0) |
| 9 | 127.0 | medium (50-500mm3) | (27.8, 87.1, 47.4) |
| 10 | 112.0 | medium (50-500mm3) | (97.5, 57.4, 74.8) |
| 11 | 103.0 | medium (50-500mm3) | (91.7, 40.8, 83.6) |
| 12 | 71.0 | medium (50-500mm3) | (52.6, 54.6, 81.6) |
| 13 | 64.0 | medium (50-500mm3) | (52.0, 78.5, 93.7) |
| 14 | 59.0 | medium (50-500mm3) | (50.7, 103.9, 85.7) |
| 15 | 40.0 | small (<50mm3) | (47.2, 30.2, 72.9) |
| 16 | 39.0 | small (<50mm3) | (43.9, 38.4, 71.6) |
| 17 | 35.0 | small (<50mm3) | (45.0, 102.5, 96.0) |
| 18 | 35.0 | small (<50mm3) | (96.0, 59.5, 60.5) |
| 19 | 31.0 | small (<50mm3) | (22.7, 90.4, 52.3) |
| 20 | 29.0 | small (<50mm3) | (39.2, 99.4, 81.6) |
| 21 | 29.0 | small (<50mm3) | (77.9, 83.6, 98.0) |
| 22 | 29.0 | small (<50mm3) | (83.5, 56.5, 85.7) |
| 23 | 27.0 | small (<50mm3) | (49.6, 119.3, 81.7) |
| 24 | 24.0 | small (<50mm3) | (53.0, 76.9, 105.5) |
| 25 | 22.0 | small (<50mm3) | (101.2, 68.7, 64.9) |
| 26 | 19.0 | small (<50mm3) | (42.4, 50.9, 84.6) |
| 27 | 16.0 | small (<50mm3) | (80.1, 120.4, 66.4) |
| 28 | 13.0 | small (<50mm3) | (85.0, 71.3, 85.6) |
| 29 | 13.0 | small (<50mm3) | (110.9, 100.8, 54.1) |
| 30 | 3.0 | small (<50mm3) | (45.3, 46.7, 71.0) |