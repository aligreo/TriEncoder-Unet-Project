# MS-CAD Report - Case MSSEG_TEST_Center_03_Patient_03
_Generated: 2026-09-12 21:27_

> Research quantification output, not a validated diagnostic device. Categories are based on standardized 50/500 mm3 volume thresholds.

## Summary (Predicted)
- **Count:** 15 | **Vol:** 1.517 mL
  - small (<50mm3): 5
  - medium (50-500mm3): 10
  - large (>500mm3): 0

## Validation vs Ground Truth
- **GT Count:** 9 | **GT Vol:** 1.211 mL
- **Detection TP/FP/FN:** 6/9/3
- **Precision/Recall/F1:** 0.400/0.667/0.500

## Lesion Detail (Predicted)
| # | Vol (mm3) | Category | Centroid |
|---|---|---|---|
| 1 | 421.0 | medium (50-500mm3) | (50.2, 72.4, 91.3) |
| 2 | 195.0 | medium (50-500mm3) | (34.3, 59.9, 59.8) |
| 3 | 195.0 | medium (50-500mm3) | (97.8, 57.7, 63.0) |
| 4 | 108.0 | medium (50-500mm3) | (51.7, 22.2, 62.3) |
| 5 | 105.0 | medium (50-500mm3) | (89.2, 62.5, 82.6) |
| 6 | 86.0 | medium (50-500mm3) | (109.4, 91.9, 78.1) |
| 7 | 78.0 | medium (50-500mm3) | (87.0, 28.4, 65.8) |
| 8 | 70.0 | medium (50-500mm3) | (80.3, 115.6, 65.2) |
| 9 | 68.0 | medium (50-500mm3) | (50.3, 115.4, 66.8) |
| 10 | 52.0 | medium (50-500mm3) | (67.0, 77.0, 84.7) |
| 11 | 45.0 | small (<50mm3) | (71.8, 101.4, 115.9) |
| 12 | 45.0 | small (<50mm3) | (104.4, 93.8, 47.3) |
| 13 | 33.0 | small (<50mm3) | (48.4, 58.3, 87.8) |
| 14 | 9.0 | small (<50mm3) | (60.9, 77.2, 81.0) |
| 15 | 7.0 | small (<50mm3) | (85.4, 20.4, 62.4) |