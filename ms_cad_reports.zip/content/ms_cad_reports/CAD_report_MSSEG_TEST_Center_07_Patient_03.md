# MS-CAD Report - Case MSSEG_TEST_Center_07_Patient_03
_Generated: 2026-09-12 21:27_

> Research quantification output, not a validated diagnostic device. Categories are based on standardized 50/500 mm3 volume thresholds.

## Summary (Predicted)
- **Count:** 30 | **Vol:** 6.334 mL
  - small (<50mm3): 14
  - medium (50-500mm3): 13
  - large (>500mm3): 3

## Validation vs Ground Truth
- **GT Count:** 26 | **GT Vol:** 7.434 mL
- **Detection TP/FP/FN:** 22/7/4
- **Precision/Recall/F1:** 0.759/0.846/0.800

## Lesion Detail (Predicted)
| # | Vol (mm3) | Category | Centroid |
|---|---|---|---|
| 1 | 1999.0 | large (>500mm3) | (46.5, 97.4, 89.0) |
| 2 | 1223.0 | large (>500mm3) | (103.7, 59.4, 62.9) |
| 3 | 732.0 | large (>500mm3) | (82.4, 115.8, 81.4) |
| 4 | 441.0 | medium (50-500mm3) | (86.3, 53.5, 77.8) |
| 5 | 417.0 | medium (50-500mm3) | (47.2, 60.3, 82.5) |
| 6 | 218.0 | medium (50-500mm3) | (45.1, 39.3, 63.6) |
| 7 | 192.0 | medium (50-500mm3) | (46.3, 52.4, 78.7) |
| 8 | 131.0 | medium (50-500mm3) | (88.1, 58.5, 89.4) |
| 9 | 125.0 | medium (50-500mm3) | (93.6, 98.6, 100.7) |
| 10 | 123.0 | medium (50-500mm3) | (101.8, 100.4, 48.8) |
| 11 | 100.0 | medium (50-500mm3) | (52.9, 77.3, 91.4) |
| 12 | 75.0 | medium (50-500mm3) | (31.0, 54.5, 57.1) |
| 13 | 72.0 | medium (50-500mm3) | (52.2, 26.2, 53.3) |
| 14 | 63.0 | medium (50-500mm3) | (82.4, 67.8, 85.6) |
| 15 | 61.0 | medium (50-500mm3) | (55.1, 94.6, 110.4) |
| 16 | 51.0 | medium (50-500mm3) | (92.1, 57.6, 59.7) |
| 17 | 44.0 | small (<50mm3) | (90.7, 82.7, 92.9) |
| 18 | 40.0 | small (<50mm3) | (100.4, 36.7, 49.0) |
| 19 | 34.0 | small (<50mm3) | (41.3, 50.6, 66.6) |
| 20 | 33.0 | small (<50mm3) | (76.5, 85.5, 37.1) |
| 21 | 29.0 | small (<50mm3) | (49.4, 53.6, 63.7) |
| 22 | 25.0 | small (<50mm3) | (92.6, 50.3, 66.8) |
| 23 | 24.0 | small (<50mm3) | (44.7, 50.8, 88.6) |
| 24 | 19.0 | small (<50mm3) | (90.2, 39.3, 70.4) |
| 25 | 19.0 | small (<50mm3) | (90.1, 68.3, 99.1) |
| 26 | 19.0 | small (<50mm3) | (98.0, 53.0, 84.4) |
| 27 | 11.0 | small (<50mm3) | (101.5, 49.9, 56.5) |
| 28 | 7.0 | small (<50mm3) | (87.7, 38.9, 53.0) |
| 29 | 4.0 | small (<50mm3) | (57.0, 70.5, 105.5) |
| 30 | 3.0 | small (<50mm3) | (95.0, 59.0, 75.0) |