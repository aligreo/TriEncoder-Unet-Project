# MS-CAD Report - Case MSSEG_TEST_Center_01_Patient_09
_Generated: 2026-09-12 21:27_

> Research quantification output, not a validated diagnostic device. Categories are based on standardized 50/500 mm3 volume thresholds.

## Summary (Predicted)
- **Count:** 12 | **Vol:** 0.648 mL
  - small (<50mm3): 9
  - medium (50-500mm3): 3
  - large (>500mm3): 0

## Validation vs Ground Truth
- **GT Count:** 13 | **GT Vol:** 0.604 mL
- **Detection TP/FP/FN:** 6/6/7
- **Precision/Recall/F1:** 0.500/0.462/0.480

## Lesion Detail (Predicted)
| # | Vol (mm3) | Category | Centroid |
|---|---|---|---|
| 1 | 214.0 | medium (50-500mm3) | (85.5, 33.3, 59.2) |
| 2 | 162.0 | medium (50-500mm3) | (81.3, 76.7, 101.0) |
| 3 | 61.0 | medium (50-500mm3) | (51.8, 66.7, 110.3) |
| 4 | 37.0 | small (<50mm3) | (47.6, 22.1, 54.5) |
| 5 | 33.0 | small (<50mm3) | (64.7, 77.7, 26.6) |
| 6 | 29.0 | small (<50mm3) | (45.6, 98.7, 50.8) |
| 7 | 29.0 | small (<50mm3) | (44.6, 119.7, 86.0) |
| 8 | 26.0 | small (<50mm3) | (92.1, 47.9, 62.0) |
| 9 | 20.0 | small (<50mm3) | (81.8, 118.5, 89.5) |
| 10 | 16.0 | small (<50mm3) | (105.1, 47.2, 79.4) |
| 11 | 11.0 | small (<50mm3) | (91.7, 102.2, 58.5) |
| 12 | 10.0 | small (<50mm3) | (92.5, 114.0, 93.8) |