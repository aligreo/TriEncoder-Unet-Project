# MS-CAD Report - Case MSSEG_TEST_Center_07_Patient_06
_Generated: 2026-09-12 21:27_

> Research quantification output, not a validated diagnostic device. Categories are based on standardized 50/500 mm3 volume thresholds.

## Summary (Predicted)
- **Count:** 7 | **Vol:** 2.136 mL
  - small (<50mm3): 1
  - medium (50-500mm3): 4
  - large (>500mm3): 2

## Validation vs Ground Truth
- **GT Count:** 9 | **GT Vol:** 3.048 mL
- **Detection TP/FP/FN:** 7/0/2
- **Precision/Recall/F1:** 1.000/0.778/0.875

## Lesion Detail (Predicted)
| # | Vol (mm3) | Category | Centroid |
|---|---|---|---|
| 1 | 861.0 | large (>500mm3) | (88.1, 55.8, 92.4) |
| 2 | 532.0 | large (>500mm3) | (41.2, 55.9, 80.4) |
| 3 | 422.0 | medium (50-500mm3) | (53.2, 128.4, 81.7) |
| 4 | 158.0 | medium (50-500mm3) | (46.8, 74.7, 91.4) |
| 5 | 85.0 | medium (50-500mm3) | (57.0, 84.8, 34.4) |
| 6 | 67.0 | medium (50-500mm3) | (86.3, 90.5, 70.8) |
| 7 | 11.0 | small (<50mm3) | (38.6, 112.9, 96.8) |