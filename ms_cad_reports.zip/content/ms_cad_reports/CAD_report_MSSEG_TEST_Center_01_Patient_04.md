# MS-CAD Report - Case MSSEG_TEST_Center_01_Patient_04
_Generated: 2026-09-12 21:26_

> Research quantification output, not a validated diagnostic device. Categories are based on standardized 50/500 mm3 volume thresholds.

## Summary (Predicted)
- **Count:** 28 | **Vol:** 39.474 mL
  - small (<50mm3): 18
  - medium (50-500mm3): 7
  - large (>500mm3): 3

## Validation vs Ground Truth
- **GT Count:** 17 | **GT Vol:** 34.821 mL
- **Detection TP/FP/FN:** 14/14/3
- **Precision/Recall/F1:** 0.500/0.824/0.622

## Lesion Detail (Predicted)
| # | Vol (mm3) | Category | Centroid |
|---|---|---|---|
| 1 | 18607.0 | large (>500mm3) | (43.5, 69.5, 82.1) |
| 2 | 18104.0 | large (>500mm3) | (93.5, 69.8, 80.7) |
| 3 | 1667.0 | large (>500mm3) | (70.4, 67.3, 77.9) |
| 4 | 290.0 | medium (50-500mm3) | (69.4, 105.4, 98.1) |
| 5 | 112.0 | medium (50-500mm3) | (75.7, 89.6, 41.9) |
| 6 | 73.0 | medium (50-500mm3) | (95.1, 94.4, 99.7) |
| 7 | 68.0 | medium (50-500mm3) | (89.8, 87.8, 72.1) |
| 8 | 58.0 | medium (50-500mm3) | (93.9, 83.9, 57.3) |
| 9 | 53.0 | medium (50-500mm3) | (65.7, 92.8, 42.6) |
| 10 | 51.0 | medium (50-500mm3) | (93.6, 103.5, 101.8) |
| 11 | 47.0 | small (<50mm3) | (82.4, 92.8, 87.2) |
| 12 | 46.0 | small (<50mm3) | (85.9, 132.5, 101.4) |
| 13 | 45.0 | small (<50mm3) | (84.7, 76.8, 39.7) |
| 14 | 33.0 | small (<50mm3) | (54.2, 85.3, 70.1) |
| 15 | 32.0 | small (<50mm3) | (99.4, 131.1, 84.7) |
| 16 | 28.0 | small (<50mm3) | (27.2, 89.0, 96.5) |
| 17 | 28.0 | small (<50mm3) | (122.8, 81.3, 93.4) |
| 18 | 22.0 | small (<50mm3) | (76.0, 87.4, 46.0) |
| 19 | 21.0 | small (<50mm3) | (48.5, 142.6, 87.6) |
| 20 | 19.0 | small (<50mm3) | (50.4, 141.6, 95.5) |
| 21 | 14.0 | small (<50mm3) | (104.3, 95.5, 98.4) |
| 22 | 13.0 | small (<50mm3) | (79.9, 21.6, 89.3) |
| 23 | 12.0 | small (<50mm3) | (64.0, 94.0, 46.5) |
| 24 | 11.0 | small (<50mm3) | (106.2, 89.8, 99.7) |
| 25 | 8.0 | small (<50mm3) | (80.0, 79.2, 129.5) |
| 26 | 5.0 | small (<50mm3) | (38.6, 81.8, 71.0) |
| 27 | 4.0 | small (<50mm3) | (41.2, 62.8, 27.0) |
| 28 | 3.0 | small (<50mm3) | (81.0, 64.3, 28.7) |