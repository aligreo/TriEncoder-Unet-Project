# MS-CAD Report - Case MSSEG_TEST_Center_03_Patient_04
_Generated: 2026-09-12 21:27_

> Research quantification output, not a validated diagnostic device. Categories are based on standardized 50/500 mm3 volume thresholds.

## Summary (Predicted)
- **Count:** 25 | **Vol:** 1.800 mL
  - small (<50mm3): 14
  - medium (50-500mm3): 11
  - large (>500mm3): 0

## Validation vs Ground Truth
- **GT Count:** 8 | **GT Vol:** 1.153 mL
- **Detection TP/FP/FN:** 8/15/0
- **Precision/Recall/F1:** 0.348/1.000/0.516

## Lesion Detail (Predicted)
| # | Vol (mm3) | Category | Centroid |
|---|---|---|---|
| 1 | 292.0 | medium (50-500mm3) | (52.7, 108.8, 100.6) |
| 2 | 258.0 | medium (50-500mm3) | (38.7, 74.1, 63.8) |
| 3 | 181.0 | medium (50-500mm3) | (89.8, 27.8, 67.1) |
| 4 | 177.0 | medium (50-500mm3) | (95.6, 88.3, 62.1) |
| 5 | 173.0 | medium (50-500mm3) | (87.0, 67.6, 94.0) |
| 6 | 109.0 | medium (50-500mm3) | (57.4, 160.7, 62.7) |
| 7 | 96.0 | medium (50-500mm3) | (84.4, 109.0, 99.5) |
| 8 | 88.0 | medium (50-500mm3) | (93.5, 56.5, 82.9) |
| 9 | 63.0 | medium (50-500mm3) | (48.1, 87.6, 52.2) |
| 10 | 52.0 | medium (50-500mm3) | (50.7, 137.0, 87.1) |
| 11 | 51.0 | medium (50-500mm3) | (51.3, 68.0, 97.1) |
| 12 | 48.0 | small (<50mm3) | (43.8, 96.1, 59.0) |
| 13 | 43.0 | small (<50mm3) | (52.4, 98.4, 97.9) |
| 14 | 32.0 | small (<50mm3) | (53.4, 82.0, 99.8) |
| 15 | 30.0 | small (<50mm3) | (42.7, 144.3, 84.1) |
| 16 | 23.0 | small (<50mm3) | (84.9, 99.2, 103.3) |
| 17 | 22.0 | small (<50mm3) | (41.8, 37.4, 65.5) |
| 18 | 15.0 | small (<50mm3) | (48.4, 55.5, 82.7) |
| 19 | 12.0 | small (<50mm3) | (101.0, 66.1, 65.6) |
| 20 | 10.0 | small (<50mm3) | (84.5, 19.6, 53.5) |
| 21 | 8.0 | small (<50mm3) | (107.5, 24.8, 84.6) |
| 22 | 7.0 | small (<50mm3) | (101.3, 48.1, 69.4) |
| 23 | 4.0 | small (<50mm3) | (97.8, 88.5, 96.2) |
| 24 | 3.0 | small (<50mm3) | (83.7, 116.0, 96.7) |
| 25 | 3.0 | small (<50mm3) | (108.3, 24.3, 54.0) |