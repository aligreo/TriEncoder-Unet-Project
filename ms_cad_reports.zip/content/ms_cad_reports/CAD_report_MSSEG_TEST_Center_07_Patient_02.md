# MS-CAD Report - Case MSSEG_TEST_Center_07_Patient_02
_Generated: 2026-09-12 21:27_

> Research quantification output, not a validated diagnostic device. Categories are based on standardized 50/500 mm3 volume thresholds.

## Summary (Predicted)
- **Count:** 18 | **Vol:** 1.371 mL
  - small (<50mm3): 8
  - medium (50-500mm3): 10
  - large (>500mm3): 0

## Validation vs Ground Truth
- **GT Count:** 15 | **GT Vol:** 0.913 mL
- **Detection TP/FP/FN:** 14/4/1
- **Precision/Recall/F1:** 0.778/0.933/0.849

## Lesion Detail (Predicted)
| # | Vol (mm3) | Category | Centroid |
|---|---|---|---|
| 1 | 318.0 | medium (50-500mm3) | (84.9, 129.6, 88.5) |
| 2 | 176.0 | medium (50-500mm3) | (83.3, 114.6, 101.8) |
| 3 | 136.0 | medium (50-500mm3) | (33.9, 61.9, 73.5) |
| 4 | 115.0 | medium (50-500mm3) | (51.9, 78.8, 106.6) |
| 5 | 106.0 | medium (50-500mm3) | (83.9, 92.2, 103.4) |
| 6 | 97.0 | medium (50-500mm3) | (49.3, 128.1, 89.5) |
| 7 | 79.0 | medium (50-500mm3) | (37.5, 53.8, 67.6) |
| 8 | 65.0 | medium (50-500mm3) | (101.2, 114.0, 80.3) |
| 9 | 62.0 | medium (50-500mm3) | (106.4, 54.3, 83.5) |
| 10 | 57.0 | medium (50-500mm3) | (95.9, 117.7, 87.0) |
| 11 | 49.0 | small (<50mm3) | (102.0, 65.3, 95.8) |
| 12 | 29.0 | small (<50mm3) | (108.4, 93.4, 101.3) |
| 13 | 28.0 | small (<50mm3) | (48.7, 120.1, 98.2) |
| 14 | 21.0 | small (<50mm3) | (87.1, 96.8, 119.5) |
| 15 | 20.0 | small (<50mm3) | (100.8, 133.2, 98.5) |
| 16 | 6.0 | small (<50mm3) | (99.2, 135.2, 90.0) |
| 17 | 4.0 | small (<50mm3) | (82.8, 150.0, 89.0) |
| 18 | 3.0 | small (<50mm3) | (36.0, 100.7, 100.7) |