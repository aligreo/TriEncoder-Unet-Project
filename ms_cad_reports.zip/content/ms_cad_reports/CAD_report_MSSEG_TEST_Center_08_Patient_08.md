# MS-CAD Report - Case MSSEG_TEST_Center_08_Patient_08
_Generated: 2026-09-12 21:27_

> Research quantification output, not a validated diagnostic device. Categories are based on standardized 50/500 mm3 volume thresholds.

## Summary (Predicted)
- **Count:** 10 | **Vol:** 1.339 mL
  - small (<50mm3): 6
  - medium (50-500mm3): 3
  - large (>500mm3): 1

## Validation vs Ground Truth
- **GT Count:** 5 | **GT Vol:** 1.194 mL
- **Detection TP/FP/FN:** 4/6/1
- **Precision/Recall/F1:** 0.400/0.800/0.533

## Lesion Detail (Predicted)
| # | Vol (mm3) | Category | Centroid |
|---|---|---|---|
| 1 | 663.0 | large (>500mm3) | (35.3, 94.8, 106.0) |
| 2 | 389.0 | medium (50-500mm3) | (49.2, 46.2, 86.1) |
| 3 | 101.0 | medium (50-500mm3) | (79.4, 107.2, 93.5) |
| 4 | 59.0 | medium (50-500mm3) | (78.3, 130.9, 69.6) |
| 5 | 46.0 | small (<50mm3) | (87.0, 33.3, 64.0) |
| 6 | 29.0 | small (<50mm3) | (109.4, 90.2, 90.2) |
| 7 | 27.0 | small (<50mm3) | (50.7, 131.0, 72.0) |
| 8 | 12.0 | small (<50mm3) | (95.5, 64.8, 86.3) |
| 9 | 8.0 | small (<50mm3) | (78.2, 123.6, 86.1) |
| 10 | 5.0 | small (<50mm3) | (51.2, 127.0, 82.6) |