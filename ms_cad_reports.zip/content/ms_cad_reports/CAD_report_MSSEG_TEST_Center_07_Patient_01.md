# MS-CAD Report - Case MSSEG_TEST_Center_07_Patient_01
_Generated: 2026-09-12 21:27_

> Research quantification output, not a validated diagnostic device. Categories are based on standardized 50/500 mm3 volume thresholds.

## Summary (Predicted)
- **Count:** 19 | **Vol:** 4.345 mL
  - small (<50mm3): 6
  - medium (50-500mm3): 12
  - large (>500mm3): 1

## Validation vs Ground Truth
- **GT Count:** 15 | **GT Vol:** 4.770 mL
- **Detection TP/FP/FN:** 14/3/1
- **Precision/Recall/F1:** 0.824/0.933/0.875

## Lesion Detail (Predicted)
| # | Vol (mm3) | Category | Centroid |
|---|---|---|---|
| 1 | 1792.0 | large (>500mm3) | (86.8, 58.9, 74.7) |
| 2 | 464.0 | medium (50-500mm3) | (43.7, 72.9, 76.0) |
| 3 | 382.0 | medium (50-500mm3) | (48.0, 121.7, 55.1) |
| 4 | 320.0 | medium (50-500mm3) | (75.9, 101.4, 73.9) |
| 5 | 318.0 | medium (50-500mm3) | (49.0, 117.1, 65.4) |
| 6 | 207.0 | medium (50-500mm3) | (78.0, 75.3, 78.8) |
| 7 | 127.0 | medium (50-500mm3) | (47.3, 101.1, 71.5) |
| 8 | 118.0 | medium (50-500mm3) | (46.7, 86.5, 62.5) |
| 9 | 117.0 | medium (50-500mm3) | (86.0, 46.3, 68.7) |
| 10 | 115.0 | medium (50-500mm3) | (75.4, 110.5, 70.6) |
| 11 | 96.0 | medium (50-500mm3) | (37.9, 48.2, 68.4) |
| 12 | 82.0 | medium (50-500mm3) | (43.4, 57.6, 81.0) |
| 13 | 57.0 | medium (50-500mm3) | (70.8, 53.5, 34.6) |
| 14 | 44.0 | small (<50mm3) | (45.8, 53.4, 60.3) |
| 15 | 30.0 | small (<50mm3) | (79.3, 127.2, 54.6) |
| 16 | 29.0 | small (<50mm3) | (79.2, 96.0, 83.0) |
| 17 | 25.0 | small (<50mm3) | (74.0, 100.8, 98.1) |
| 18 | 13.0 | small (<50mm3) | (72.8, 23.2, 71.3) |
| 19 | 9.0 | small (<50mm3) | (95.3, 61.7, 52.3) |