# MS-CAD Report - Case MSSEG_TEST_Center_01_Patient_07
_Generated: 2026-09-12 21:27_

> Research quantification output, not a validated diagnostic device. Categories are based on standardized 50/500 mm3 volume thresholds.

## Summary (Predicted)
- **Count:** 26 | **Vol:** 2.966 mL
  - small (<50mm3): 13
  - medium (50-500mm3): 11
  - large (>500mm3): 2

## Validation vs Ground Truth
- **GT Count:** 32 | **GT Vol:** 4.596 mL
- **Detection TP/FP/FN:** 19/2/13
- **Precision/Recall/F1:** 0.905/0.594/0.717

## Lesion Detail (Predicted)
| # | Vol (mm3) | Category | Centroid |
|---|---|---|---|
| 1 | 665.0 | large (>500mm3) | (87.5, 125.3, 90.7) |
| 2 | 604.0 | large (>500mm3) | (87.1, 83.6, 94.9) |
| 3 | 482.0 | medium (50-500mm3) | (95.5, 44.9, 66.4) |
| 4 | 238.0 | medium (50-500mm3) | (52.0, 84.6, 92.7) |
| 5 | 122.0 | medium (50-500mm3) | (40.2, 45.5, 64.2) |
| 6 | 121.0 | medium (50-500mm3) | (50.6, 132.9, 82.7) |
| 7 | 91.0 | medium (50-500mm3) | (51.5, 125.0, 91.0) |
| 8 | 86.0 | medium (50-500mm3) | (30.4, 59.6, 71.7) |
| 9 | 82.0 | medium (50-500mm3) | (93.0, 107.4, 89.7) |
| 10 | 70.0 | medium (50-500mm3) | (82.9, 132.7, 76.0) |
| 11 | 59.0 | medium (50-500mm3) | (50.4, 144.3, 88.4) |
| 12 | 57.0 | medium (50-500mm3) | (53.2, 115.5, 95.1) |
| 13 | 51.0 | medium (50-500mm3) | (74.5, 79.5, 39.7) |
| 14 | 47.0 | small (<50mm3) | (31.7, 69.9, 58.4) |
| 15 | 31.0 | small (<50mm3) | (114.2, 98.7, 88.4) |
| 16 | 29.0 | small (<50mm3) | (25.5, 80.7, 54.4) |
| 17 | 28.0 | small (<50mm3) | (102.8, 98.5, 92.5) |
| 18 | 18.0 | small (<50mm3) | (31.9, 123.1, 89.6) |
| 19 | 15.0 | small (<50mm3) | (64.9, 79.7, 39.6) |
| 20 | 15.0 | small (<50mm3) | (110.0, 65.4, 62.0) |
| 21 | 14.0 | small (<50mm3) | (92.7, 112.9, 88.6) |
| 22 | 13.0 | small (<50mm3) | (101.0, 74.4, 100.2) |
| 23 | 10.0 | small (<50mm3) | (43.2, 117.1, 88.6) |
| 24 | 9.0 | small (<50mm3) | (76.3, 17.4, 76.4) |
| 25 | 6.0 | small (<50mm3) | (107.0, 77.0, 66.2) |
| 26 | 3.0 | small (<50mm3) | (34.7, 138.0, 85.3) |