# MS-CAD Report - Case MSSEG_TEST_Center_07_Patient_10
_Generated: 2026-09-12 21:27_

> Research quantification output, not a validated diagnostic device. Categories are based on standardized 50/500 mm3 volume thresholds.

## Summary (Predicted)
- **Count:** 14 | **Vol:** 13.772 mL
  - small (<50mm3): 5
  - medium (50-500mm3): 5
  - large (>500mm3): 4

## Validation vs Ground Truth
- **GT Count:** 11 | **GT Vol:** 11.146 mL
- **Detection TP/FP/FN:** 9/5/2
- **Precision/Recall/F1:** 0.643/0.818/0.720

## Lesion Detail (Predicted)
| # | Vol (mm3) | Category | Centroid |
|---|---|---|---|
| 1 | 5912.0 | large (>500mm3) | (91.8, 57.1, 77.5) |
| 2 | 4905.0 | large (>500mm3) | (43.4, 63.9, 77.2) |
| 3 | 1159.0 | large (>500mm3) | (88.1, 104.1, 78.8) |
| 4 | 594.0 | large (>500mm3) | (49.3, 104.9, 77.4) |
| 5 | 414.0 | medium (50-500mm3) | (91.4, 95.7, 87.2) |
| 6 | 289.0 | medium (50-500mm3) | (35.2, 44.8, 56.7) |
| 7 | 222.0 | medium (50-500mm3) | (55.2, 96.9, 107.3) |
| 8 | 86.0 | medium (50-500mm3) | (85.0, 117.6, 70.4) |
| 9 | 53.0 | medium (50-500mm3) | (47.8, 116.0, 73.1) |
| 10 | 49.0 | small (<50mm3) | (99.0, 65.1, 63.7) |
| 11 | 34.0 | small (<50mm3) | (54.6, 112.6, 54.0) |
| 12 | 31.0 | small (<50mm3) | (37.7, 76.3, 75.1) |
| 13 | 14.0 | small (<50mm3) | (94.8, 104.0, 56.8) |
| 14 | 10.0 | small (<50mm3) | (28.7, 47.7, 58.4) |