# MS-CAD Report - Case MSSEG_TEST_Center_03_Patient_06
_Generated: 2026-09-12 21:27_

> Research quantification output, not a validated diagnostic device. Categories are based on standardized 50/500 mm3 volume thresholds.

## Summary (Predicted)
- **Count:** 17 | **Vol:** 1.388 mL
  - small (<50mm3): 6
  - medium (50-500mm3): 11
  - large (>500mm3): 0

## Validation vs Ground Truth
- **GT Count:** 9 | **GT Vol:** 0.655 mL
- **Detection TP/FP/FN:** 8/9/1
- **Precision/Recall/F1:** 0.471/0.889/0.615

## Lesion Detail (Predicted)
| # | Vol (mm3) | Category | Centroid |
|---|---|---|---|
| 1 | 382.0 | medium (50-500mm3) | (33.1, 70.8, 57.3) |
| 2 | 126.0 | medium (50-500mm3) | (48.9, 79.3, 86.9) |
| 3 | 112.0 | medium (50-500mm3) | (46.1, 24.0, 67.8) |
| 4 | 109.0 | medium (50-500mm3) | (77.3, 27.0, 67.0) |
| 5 | 108.0 | medium (50-500mm3) | (85.4, 75.5, 90.5) |
| 6 | 108.0 | medium (50-500mm3) | (94.0, 64.7, 59.4) |
| 7 | 103.0 | medium (50-500mm3) | (29.9, 78.7, 89.0) |
| 8 | 74.0 | medium (50-500mm3) | (78.4, 120.3, 60.0) |
| 9 | 63.0 | medium (50-500mm3) | (50.8, 120.0, 61.9) |
| 10 | 63.0 | medium (50-500mm3) | (91.8, 70.1, 86.6) |
| 11 | 56.0 | medium (50-500mm3) | (35.9, 43.3, 71.4) |
| 12 | 22.0 | small (<50mm3) | (97.1, 67.2, 53.0) |
| 13 | 16.0 | small (<50mm3) | (81.5, 123.2, 65.2) |
| 14 | 15.0 | small (<50mm3) | (86.6, 59.3, 87.0) |
| 15 | 14.0 | small (<50mm3) | (60.9, 53.2, 70.4) |
| 16 | 14.0 | small (<50mm3) | (81.0, 121.2, 70.9) |
| 17 | 3.0 | small (<50mm3) | (51.3, 119.3, 73.7) |